enum UserRole { student, staff, lecturer }
enum RoomStatus { active, disabled }
enum SlotStatus { free, pending, reserved, disabled }
enum RequestStatus { pending, approved, rejected }
